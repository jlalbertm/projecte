<?php $__env->startSection('title','Formulari nou Cicle formatiu'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Crear cicle formatiu</h1>
    
    <form action="<?php echo e(route('ciclosFormativos.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="title">Nom del cicle formatiu:</label>
            <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e(old('nombre')); ?>">

            <?php if($errors->has('nombre')): ?>
                <div class="text-danger"><?php echo e($errors->first('nombre')); ?></div>
            <?php endif; ?>

        </div>
        <div class="form-group">
            <label for="editorial">Família professional a la qual pertany:</label>

            <input type="text" class="form-control" name="familia_profesional" id="familia_profesional" value="<?php echo e(old('familia_profesional')); ?>">
                <?php if($errors->has('familia_profesional')): ?>
                <div class="text-danger"><?php echo e($errors->first('familia_profesional')); ?></div>
            <?php endif; ?>

        </div>
        <div class="form-group">
            <label for="price">Grau:</label>
            <select class="form-control" name="grado" id="grado">
                <option value="Grau Mitjà" <?php echo e(old('grado') == 'Grau Mitjà' ? 'selected' : ''); ?>>Grau Mitjà</option>
                <option value="Grau Superior" <?php echo e(old('grado') == 'Grau Superior' ? 'selected' : ''); ?>>Grau Superior</option>
            </select>

            <?php if($errors->has('grado')): ?>
                <div class="text-danger"><?php echo e($errors->first('grado')); ?></div>
            <?php endif; ?>


        </div>
        <div class="form-group">
            <label for="author">Modalitat:</label>
           <select class="form-control" name="modalidad" id="modalidad">
                <option value="Presencial " <?php echo e(old('modalidad') == 'Presencial' ? 'selected' : ''); ?>>Presencial</option>
                <option value="Semipresencial" <?php echo e(old('modalidad') == 'Semipresencial' ? 'selected' : ''); ?>>Semipresencial</option>

            </select>

            <?php if($errors->has('modalidad')): ?>
                <div class="text-danger"><?php echo e($errors->first('modalidad')); ?></div>
            <?php endif; ?>
        </div>
        <div class="form-group">
            <label for="title">Referència normativa del títol (BOE/DOGV):</label>
            <input type="text" class="form-control" name="decreto_referencia" id="decreto_referencia" value="<?php echo e(old('decreto_referencia')); ?>">

            <?php if($errors->has('decreto_referencia')): ?>
                <div class="text-danger"><?php echo e($errors->first('decreto_referencia')); ?></div>
            <?php endif; ?>

        </div>


        <div class="form-group">
            <label for="author">Actiu:</label>
           <select class="form-control" name="activo" id="activo">
                <option value="1" <?php echo e(old('activo') === '1' ? 'selected' : ''); ?>>SÍ</option>
                <option value="0" <?php echo e(old('activo') === '0' ? 'selected' : ''); ?>>NO</option>
            </select>
            <?php if($errors->has('activo')): ?>
                <div class="text-danger"><?php echo e($errors->first('activo')); ?></div>
            <?php endif; ?>
        </div>
        <input type="submit" name="Crear" value="Crear" class="btn btn-success btn-block">

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/ciclosFormativos/create.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Llista de Cicles Formatius'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Cicles formatius</h1>
    <ul>
        <?php $__empty_1 = true; $__currentLoopData = $ciclosFormativos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $CiclosFormativo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <li><a href="<?php echo e(route('ciclosFormativos.show',$CiclosFormativo)); ?>"><?php echo e($CiclosFormativo->nombre); ?>


            </a>
            <form action="<?php echo e(route('ciclosFormativos.destroy',$CiclosFormativo)); ?>" method="POST">
                <?php echo method_field('DELETE'); ?>
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-danger">Borrar</button>
            </form>

            <!--<form action="<?php echo e(route('ciclosFormativos.edit', $CiclosFormativo)); ?>">
                <?php echo csrf_field(); ?>
                <button type="submit" class="btn btn-warning">Editar</button>
            </form>-->
            <a href="<?php echo e(route('ciclosFormativos.edit', $CiclosFormativo)); ?>" class="btn btn-warning">Editar</a>

            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <li>No hi han cicles formatius que mostrar</li>
        <?php endif; ?>
    </ul>
    <?php echo e($ciclosFormativos->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/ciclosFormativos/index.blade.php ENDPATH**/ ?>
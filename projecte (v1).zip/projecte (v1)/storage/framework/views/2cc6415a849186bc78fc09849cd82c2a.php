<?php $__env->startSection('title','Formulari editar Cicle formatiu'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Editar Cicle Formatiu</h1>
    <form action="<?php echo e(route('ciclosFormativos.update', $CiclosFormativo)); ?>" method="POST">

        <?php echo method_field('PUT'); ?>
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="nombre">Nom del cicle formatiu:</label>
            <input type="text" class="form-control" name="nombre" id="nombre" value="<?php echo e($CiclosFormativo->nombre); ?>">
        </div>
        <div class="form-group">
            <label for="familia_profesional">Família professional a la qual pertany:</label>
            <input type="text" class="form-control" name="familia_profesional" id="familia_profesional" value="<?php echo e($CiclosFormativo->familia_profesional); ?>">
        </div>
        <div class="form-group">
            <label for="price">Grau:</label>
            <select class="form-control" name="grado" id="grado">
                <option value="Grau Mitjà" <?php echo e(old('grado', $CiclosFormativo->grado) == 'Grau Mitjà' ? 'selected' : ''); ?>>Grau Mitjà</option>
                <option value="Grau Superior" <?php echo e(old('grado', $CiclosFormativo->grado) == 'Grau Superior' ? 'selected' : ''); ?>>Grau Superior</option>
            </select>

        </div>
        <div class="form-group">
            <label for="author">Modalitat:</label>
            <select class="form-control" name="modalidad" id="modalidad">
                <option value="Presencial" <?php echo e(old('modalidad', $CiclosFormativo->modalidad) == 'Presencial' ? 'selected' : ''); ?>>Presencial</option>
                <option value="Semipresencial" <?php echo e(old('modalidad', $CiclosFormativo->modalidad) == 'Semipresencial' ? 'selected' : ''); ?>>Semipresencial</option>

            </select>
        </div>
        <div class="form-group">
            <label for="decreto_referencia">Referència normativa del títol (BOE/DOGV):</label>
            <input type="text" class="form-control" name="decreto_referencia" id="decreto_referencia" value="<?php echo e($CiclosFormativo->decreto_referencia); ?>">
        </div>
        <div class="form-group">
            <label for="decreto_referencia">Actiu:</label>
            <select class="form-control" name="activo" id="activo">
                <option value="1" <?php echo e(old('activo', $CiclosFormativo->activo) == 1 ? 'selected' : ''); ?>>SÍ</option>
                <option value="0" <?php echo e(old('activo', $CiclosFormativo->activo) == 0 ? 'selected' : ''); ?>>NO</option>
            </select>

        </div>
        <input type="submit" name="Editar" value="Editar" class="btn btn-warning btn-block">

    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/ciclosFormativos/edit.blade.php ENDPATH**/ ?>
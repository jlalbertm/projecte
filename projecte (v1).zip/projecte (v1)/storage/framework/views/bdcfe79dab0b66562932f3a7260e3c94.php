<?php $__env->startSection('title','Dades del cicle formatiu'); ?>
<?php $__env->startSection('content'); ?>
    <h1>Nom del cicle formatiu: <?php echo e($CiclosFormativo->nombre); ?></h1>
    <p>Família professional a la qual pertany: <?php echo e($CiclosFormativo->familia_profesional); ?></p>
    <p>Grau: <?php echo e($CiclosFormativo->grado); ?></p>
    <p>Modalitat: <?php echo e($CiclosFormativo->modalidad); ?></p>
    <p>Referència normativa del títol (BOE/DOGV): <?php echo e($CiclosFormativo->decreto_referencia); ?></p>
    <p>Actiu: <?php echo e($CiclosFormativo->activo ? 'SÍ' : 'NO'); ?></p>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/ciclosFormativos/show.blade.php ENDPATH**/ ?>
<?php $__env->startSection('title','Error 404'); ?>
<?php $__env->startSection('content'); ?>
    <h1 style="color:tomato;">ERROR 404</h1>
    <p>Pàgina no trobada</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('template', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /app/resources/views/errors/404.blade.php ENDPATH**/ ?>
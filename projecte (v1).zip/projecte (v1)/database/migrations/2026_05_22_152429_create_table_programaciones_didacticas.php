<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        /*
        estructura del a taula
        Camp	Descripció
        título	Títol de la programació didàctica (text curt)
        módulo	Nom del mòdul o assignatura
        ciclo_formativo	Cicle formatiu al qual pertany (FK a taula ciclos)
        curso_académico	Any acadèmic, ex: 2025-2026
        docente	Nom del professor/a responsable
        horas_totales	Nombre total d'hores del mòdul
        objetivos	Objectius generals del mòdul (tipus MEMO / text llarg)
        contenidos	Continguts organitzats per unitats (tipus MEMO)
        metodología	Descripció de la metodologia emprada (tipus MEMO)
        criterios_evaluacion	Criteris d'avaluació (tipus MEMO)
        instrumentos_evaluacion	Instruments usats per avaluar (tipus MEMO)
        recursos_materiales	Recursos i materials necessaris (tipus MEMO)
        atencion_diversidad	Mesures d'atenció a la diversitat (tipus MEMO)
        observaciones	Camp lliure per a notes addicionals (tipus MEMO)
        */
        Schema::create('programaciones_didacticas', function (Blueprint $table) {
            $table->id();
            $table->string('titulo',100);
            $table->string('modulo',100);
            $table->foreignId('ciclo_formativo_id')
                ->constrained('ciclos_formativos'); //FK
            $table->string('curso_academico', 50);
            $table->string('docente',200);
            $table->integer('horas_totales');
            $table->text('objetivos');
            $table->text('contenidos');
            $table->text('metodologia');
            $table->text('criterios_evaluacion');
            $table->text('instrumentos_evaluacion');
            $table->text('recursos_materiales');
            $table->text('atencion_diversidad');
            $table->text('observaciones')->nullable(); //crec que es millor que puga ser NULL
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('programaciones_didacticas');
    }
};
